#!/usr/bin/env python3
"""FrameForge 3D phishing-awareness explainer. 2D sprites animate inside a full 3D set."""
import bpy, math, os, sys, json, argparse, subprocess, random
from mathutils import Vector

FPS, DURATION, WIDTH, HEIGHT = 30, 120, 720, 1280
TOTAL_FRAMES = FPS * DURATION
SEGMENT_SECONDS = 15
SEGMENT_FRAMES = FPS * SEGMENT_SECONDS
STAGE_COUNT = 8
STAGE_SPACING = 24.0
OUT_NAME = "CyberSpace_Unlocked_Phishing_Awareness_120s"

PAL = {
 "void":(0.004,0.012,0.028,1), "floor":(0.012,0.035,0.065,1),
 "panel":(0.014,0.055,0.092,1), "panel2":(0.025,0.105,0.145,1),
 "steel":(0.075,0.15,0.22,1), "white":(0.84,0.94,0.99,1),
 "muted":(0.34,0.53,0.65,1), "cyan":(0.015,0.73,1.0,1),
 "blue":(0.035,0.28,0.92,1), "teal":(0.02,0.62,0.59,1),
 "amber":(1.0,0.55,0.12,1), "red":(0.96,0.08,0.14,1),
 "green":(0.09,0.88,0.49,1), "grid":(0.02,0.16,0.23,1),
 "black":(0.003,0.008,0.018,1), "purple":(0.25,0.12,0.62,1)
}
SHOTS = [
 ("PHISHING: DON'T TAKE THE BAIT", "One message can put an account at risk"),
 ("A FAMILIAR NAME CAN BE FAKE", "Phishing impersonates trusted organisations"),
 ("FIVE RED FLAGS", "Sender • urgency • links • attachments • secrets"),
 ("HELP MORE PEOPLE SPOT THE SIGNS", "Like this video and subscribe for practical cyber tips"),
 ("DON'T CLICK. VERIFY SEPARATELY.", "Open the official app or known website yourself"),
 ("YOUR PASSWORDS AND CODES ARE PRIVATE", "Never share a password or one-time sign-in code"),
 ("ALREADY CLICKED? TAKE THESE STEPS", "Stop • close • secure the real account • report"),
 ("PAUSE. VERIFY. PROTECT.", "Build your knowledge with CyberSpace Unlocked")
]


def parse_args():
    a = sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=("audit","render"), default="audit")
    p.add_argument("--segment-index", type=int, default=0)
    p.add_argument("--output-dir", default="output/phishing_explainer")
    return p.parse_args(a)


def safe_set(o, key, value):
    try: setattr(o, key, value)
    except Exception: pass


def material(name, color, metal=0.15, rough=0.38, glow=0.0):
    m = bpy.data.materials.new(name); m.diffuse_color=color; m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF")
    if bs:
        bs.inputs["Base Color"].default_value=color
        bs.inputs["Metallic"].default_value=metal
        bs.inputs["Roughness"].default_value=rough
        if "Emission Color" in bs.inputs: bs.inputs["Emission Color"].default_value=color
        elif "Emission" in bs.inputs: bs.inputs["Emission"].default_value=color
        if "Emission Strength" in bs.inputs: bs.inputs["Emission Strength"].default_value=glow
    return m


def image_material(name, image, transparent=True):
    m=bpy.data.materials.new(name); m.use_nodes=True
    nt=m.node_tree; nt.nodes.clear()
    out=nt.nodes.new("ShaderNodeOutputMaterial")
    tex=nt.nodes.new("ShaderNodeTexImage"); tex.image=image; tex.interpolation="Linear"
    if transparent:
        em=nt.nodes.new("ShaderNodeEmission"); tr=nt.nodes.new("ShaderNodeBsdfTransparent")
        mix=nt.nodes.new("ShaderNodeMixShader")
        nt.links.new(tex.outputs["Color"],em.inputs["Color"])
        nt.links.new(tex.outputs["Alpha"],mix.inputs[0])
        nt.links.new(tr.outputs[0],mix.inputs[1]); nt.links.new(em.outputs[0],mix.inputs[2])
        nt.links.new(mix.outputs[0],out.inputs["Surface"])
        safe_set(m,"blend_method","BLEND")
        safe_set(m,"surface_render_method","DITHERED")
    else:
        em=nt.nodes.new("ShaderNodeEmission")
        nt.links.new(tex.outputs["Color"],em.inputs["Color"])
        nt.links.new(em.outputs[0],out.inputs["Surface"])
    return m


def attach(o,m):
    if m: o.data.materials.append(m)
    return o


def bevel(o,w=0.05,seg=4):
    if w>0:
        b=o.modifiers.new("Soft precision bevel","BEVEL"); b.width=w; b.segments=seg
        try: o.modifiers.new("Weighted normals","WEIGHTED_NORMAL")
        except Exception: pass
    return o


def box(name,loc,size,m,w=0.05):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    o=bpy.context.object; o.name=name; o.dimensions=size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    attach(o,m); bevel(o,w); return o


def sphere(name,loc,scale,m,seg=32,rings=20):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=seg,ring_count=rings,radius=1,location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale; attach(o,m)
    for f in o.data.polygons: f.use_smooth=True
    return o


def torus(name,loc,major,minor,m,rot=(math.pi/2,0,0)):
    bpy.ops.mesh.primitive_torus_add(major_radius=major,minor_radius=minor,major_segments=64,minor_segments=12,location=loc,rotation=rot)
    o=bpy.context.object; o.name=name; attach(o,m)
    for f in o.data.polygons: f.use_smooth=True
    return o


def curve_line(name,pts,width,m):
    d=bpy.data.curves.new(name,"CURVE"); d.dimensions="3D"; d.resolution_u=12
    d.bevel_depth=width; d.bevel_resolution=3
    s=d.splines.new("POLY"); s.points.add(len(pts)-1)
    for p,v in zip(s.points,pts): p.co=(v[0],v[1],v[2],1)
    o=bpy.data.objects.new(name,d); bpy.context.collection.objects.link(o); attach(o,m)
    return o


def text_obj(name,body,loc,size,m,align="CENTER"):
    d=bpy.data.curves.new(name,"FONT"); d.body=body; d.size=size; d.align_x=align
    d.align_y="CENTER"; d.extrude=0.003; d.bevel_depth=0.0008
    o=bpy.data.objects.new(name,d); bpy.context.collection.objects.link(o)
    o.location=loc; o.rotation_euler=(math.pi/2,0,0); attach(o,m); return o


def panel(name,x,y,z,title,sub,M,width=6.8,height=2.0,accent=None):
    accent=accent or M["cyan"]
    box(name+" chassis",(x,y,z),(width,0.38,height),M["panel"],0.15)
    box(name+" edge",(x-width/2+0.10,y-0.205,z),(0.07,0.04,height-0.35),accent,0.02)
    text_obj(name+" title",title,(x,y-0.222,z+0.34),0.34,M["white"])
    text_obj(name+" detail",sub,(x,y-0.224,z-0.28),0.18,M["muted"])


def add_image_plane(name,path,loc,w,h,transparent=True):
    img=bpy.data.images.load(path,check_existing=True)
    mat=image_material(name+" image material",img,transparent)
    bpy.ops.mesh.primitive_plane_add(size=1,location=loc)
    o=bpy.context.object; o.name=name; o.rotation_euler=(math.pi/2,0,0)
    o.scale=(w,h,1); attach(o,mat)
    return o


def key_visibility(o,start,end):
    o.hide_render=True
    if start>1:
        o.keyframe_insert(data_path="hide_render",frame=1)
        o.keyframe_insert(data_path="hide_render",frame=start-1)
    o.hide_render=False; o.keyframe_insert(data_path="hide_render",frame=start)
    o.keyframe_insert(data_path="hide_render",frame=end)
    o.hide_render=True; o.keyframe_insert(data_path="hide_render",frame=end+1)
    try:
        for fc in o.animation_data.action.fcurves:
            if fc.data_path=="hide_render":
                for kp in fc.keyframe_points: kp.interpolation="CONSTANT"
    except Exception: pass


def stage_sprites(root_dir):
    """Create all 2D character planes before any 3D environment construction."""
    states={
      0:{"maya":["surprised","suspicious","focused"],"juno":["neutral","thinking","neutral"]},
      1:{"maya":["suspicious","thinking","focused"],"juno":["neutral","suspicious","thinking"]},
      2:{"maya":["suspicious","focused","thinking"],"juno":["thinking","suspicious","focused"]},
      3:{"maya":["neutral","happy","happy"],"juno":["neutral","happy","happy"]},
      4:{"maya":["thinking","suspicious","focused"],"juno":["neutral","pointing","focused"]},
      5:{"maya":["focused","thinking","confident"],"juno":["suspicious","focused","confident"]},
      6:{"maya":["surprised","thinking","relieved"],"juno":["concerned","thinking","relieved"]},
      7:{"maya":["relieved","happy","happy"],"juno":["relieved","happy","happy"]}
    }
    file_state={"pointing":"suspicious","confident":"focused","concerned":"surprised"}
    sprites=[]
    for i in range(STAGE_COUNT):
        cx=i*STAGE_SPACING
        for char in ("maya","juno"):
            for k,expr in enumerate(states[i][char]):
                actual=file_state.get(expr,expr)
                pose={"neutral":"neutral","surprised":"open","suspicious":"point","thinking":"thinking","focused":"confident","relieved":"open","happy":"thumbsup"}[actual]
                path=os.path.join(root_dir,"assets","characters",f"{char}_{actual}_{pose}.png")
                if not os.path.exists(path): raise FileNotFoundError(path)
                x=cx+(-2.6 if char=="maya" else 2.6)
                # The sprite image itself is 2D; this plane is placed in real 3D space.
                ob=add_image_plane(f"2D character {char} stage {i+1} state {k+1}",path,(x,-2.2,2.65),2.3,3.45,True)
                sprites.append({"object":ob,"stage":i,"state":k,"char":char,"home_x":x})
    return sprites


def environment_base(M,world):
    world.color=PAL["void"]
    if world.use_nodes:
        world.node_tree.nodes["Background"].inputs["Color"].default_value=PAL["void"]
        world.node_tree.nodes["Background"].inputs["Strength"].default_value=0.30
    # Shared dark cyber-city corridor; every stage has its own fully modelled set.
    for i in range(STAGE_COUNT):
        x=i*STAGE_SPACING
        box(f"Stage {i+1} floor plinth",(x,0,-0.78),(13.5,19,0.55),M["floor"],0.22)
        # Fine circuit-grid lines and glowing perimeter rails.
        for gx in (-5.8,-4.2,-2.6,-1.0,0.6,2.2,3.8,5.4):
            curve_line("Floor circuit longitudinal",[(x+gx,-8,-0.48),(x+gx,8,-0.48)],0.008,M["grid"])
        for gy in (-7,-5,-3,-1,1,3,5,7):
            curve_line("Floor circuit cross",[(x-6.4,gy,-0.48),(x+6.4,gy,-0.48)],0.008,M["grid"])
        for side in (-1,1):
            box("Stage neon rail",(x+side*6.45,0,-0.46),(0.055,17,0.06),M["cyan"],0.02)
            # Server towers form a layered 3D skyline behind the action.
            for j in range(3):
                z=2.0+j*2.25
                tower=box("Server monolith",(x+side*(5.0+0.35*(j%2)),4.9,z),(1.05,1.5,2.0),M["steel"],0.12)
                box("Server front light",(tower.location.x,4.12,z),(0.62,0.055,0.10),M["cyan"] if j%2==0 else M["teal"],0.03)
                for r in range(3):
                    box("Server status diode",(tower.location.x-0.22+r*0.22,4.10,z-0.36),(0.07,0.04,0.07),M["green"] if r==0 else M["blue"],0.02)
        # Floating nodes and orbital links animate gently over the set.
        for j in range(7):
            xx=x-4.8+j*1.6; zz=8.5+0.55*math.sin(j*1.2)
            sphere("Data node",(xx,3.2,zz),(0.11,0.11,0.11),M["cyan"] if j%2==0 else M["teal"],20,12)
            if j:
                curve_line("Network filament",[(xx-1.6,3.2,8.5+0.55*math.sin((j-1)*1.2)),(xx,3.2,zz)],0.012,M["grid"])
        torus("Hologram ring",(x,3.1,7.7),2.1,0.025,M["blue"],(math.pi/2,0,0))
        text_obj("Stage identifier",f"CYBERSPACE / FIELD {i+1:02d}",(x,-0.2,11.5),0.16,M["cyan"])


def stage_specific(M,cover_path):
    for i in range(STAGE_COUNT):
        x=i*STAGE_SPACING
        title,sub=SHOTS[i]
        text_obj(f"Main heading {i+1}",title,(x,1.20,10.2),0.29,M["white"])
        text_obj(f"Main subheading {i+1}",sub,(x,1.18,9.55),0.16,M["muted"])
        if i==0:
            panel("Incoming message",x,1.1,7.2,"ACCOUNT ALERT","Your account needs attention",M,6.6,2.0,M["red"])
            box("Message red alert bar",(x,0.86,7.75),(5.5,0.05,0.10),M["red"],0.03)
            panel("Urgent button",x,0.0,4.45,"VERIFY NOW","Unexpected link inside a message",M,5.7,1.6,M["amber"])
            # Three-dimensional phone prop, separate from the 2D character.
            box("Phone body",(x+2.3,-0.2,2.8),(1.25,0.36,2.25),M["black"],0.16)
            box("Phone screen",(x+2.3,-0.40,2.82),(1.08,0.035,1.94),M["panel2"],0.10)
            text_obj("Phone lock", "!",(x+2.3,-0.43,3.05),0.55,M["red"])
            torus("Urgency alert",(x+2.3,-0.45,4.05),0.35,0.06,M["amber"])
        elif i==1:
            panel("Imposter sender",x,1.05,7.3,"FROM: SUPPORT TEAM","support@secure-account-check.example",M,6.7,2.0,M["red"])
            panel("Message copy",x,1.05,4.65,"YOUR ACCOUNT WILL CLOSE","A familiar name does not prove identity",M,6.7,1.65,M["amber"])
            # Generic imitation badge and broken verification ring.
            torus("Spoof identity ring",(x,0.1,2.1),1.0,0.10,M["red"])
            curve_line("Broken ring slash",[(x-0.72,-0.18,1.45),(x+0.72,-0.18,2.75)],0.09,M["red"])
            text_obj("Spoof warning","DISPLAY NAME ≠ VERIFIED SENDER",(x,-0.45,0.45),0.19,M["amber"])
        elif i==2:
            rows=[("01  SENDER DOESN'T MATCH","Look beyond the display name",M["red"]),
                  ("02  URGENT PRESSURE","Rushing you is part of the trick",M["amber"]),
                  ("03  UNEXPECTED LINK","Destination does not fit the claim",M["red"]),
                  ("04  ODD ATTACHMENT","You were not expecting the file",M["amber"]),
                  ("05  ASKS FOR SECRETS","Password, payment, or sign-in code",M["red"])]
            for k,(a,b,c) in enumerate(rows):
                z=8.15-k*1.45
                panel(f"Warning sign {k+1}",x,0.85,z,a,b,M,6.6,1.12,c)
        elif i==3:
            panel("Middle CTA",x,1.0,7.9,"LIKE  •  SUBSCRIBE","Help more people learn to stay safer online",M,6.9,2.1,M["cyan"])
            torus("Like icon halo",(x-1.45,-0.15,4.8),0.72,0.09,M["cyan"])
            text_obj("Like icon","+1",(x-1.45,-0.3,4.8),0.42,M["white"])
            torus("Subscribe icon halo",(x+1.45,-0.15,4.8),0.72,0.09,M["red"])
            text_obj("Subscribe icon","▶",(x+1.45,-0.3,4.8),0.42,M["white"])
            text_obj("Mid CTA kicker","FREE, PRACTICAL CYBERSECURITY LESSONS",(x,-0.3,2.8),0.17,M["muted"])
        elif i==4:
            panel("Unsafe link",x-1.7,1.0,7.1,"MESSAGE LINK","Unknown destination",M,3.0,1.8,M["red"])
            panel("Safe route",x+1.7,1.0,7.1,"OFFICIAL APP","Open it yourself",M,3.0,1.8,M["green"])
            curve_line("Unsafe route",[(x-1.7,0.7,5.9),(x-1.7,0.7,3.9)],0.06,M["red"])
            curve_line("Safe route",[(x+1.7,0.7,5.9),(x+1.7,0.7,3.9)],0.06,M["green"])
            sphere("Safe destination",(x+1.7,0.55,3.55),(0.55,0.28,0.55),M["green"])
            text_obj("Safe route label","CHECK THE ALERT THERE",(x,-0.2,2.0),0.22,M["green"])
        elif i==5:
            # Large shield and private code card.
            torus("Password shield halo",(x,0.2,6.5),2.0,0.08,M["cyan"])
            sphere("Password shield core",(x,0.15,6.5),(1.35,0.35,1.55),M["blue"])
            curve_line("Shield outline",[(x,0,8.0),(x+1.1,0,7.45),(x+0.9,0,5.5),(x,0,4.85),(x-0.9,0,5.5),(x-1.1,0,7.45),(x,0,8.0)],0.09,M["cyan"])
            text_obj("Shield lock","LOCK",(x,-0.27,6.55),0.33,M["white"])
            panel("Private information",x,-0.1,3.0,"NEVER SHARE YOUR CODE","Legitimate support should not ask for it",M,6.3,1.25,M["amber"])
        elif i==6:
            rows=[("1  STOP","Do not enter details",M["red"]),
                  ("2  CLOSE THE PAGE","Leave the suspicious site",M["amber"]),
                  ("3  SECURE THE REAL ACCOUNT","Change an exposed password; enable MFA",M["green"]),
                  ("4  REPORT AND CONTACT SUPPORT","Tell your bank or IT team when relevant",M["cyan"])]
            for k,(a,b,c) in enumerate(rows):
                z=7.75-k*1.55
                panel(f"Recovery step {k+1}",x,0.85,z,a,b,M,6.5,1.2,c)
        elif i==7:
            panel("Book CTA",x-1.25,1.0,7.9,"KEEP LEARNING","Build real-world digital security knowledge",M,4.6,1.8,M["green"])
            # Physical cover display plane is loaded from the user's supplied front cover.
            if os.path.exists(cover_path):
                ob=add_image_plane("CyberSpace Unlocked book cover",cover_path,(x+2.0,0.15,4.8),2.55,3.82,False)
                ob.rotation_euler=(math.pi/2,0,0)
                box("Book cover pedestal",(x+2.0,0.55,2.65),(3.2,1.7,0.35),M["steel"],0.12)
                box("Book side spine",(x+0.72,0.20,4.8),(0.12,0.34,3.82),M["teal"],0.03)
            text_obj("Final purchase CTA","BUY CYBERSPACE UNLOCKED",(x-1.1,-0.2,5.15),0.26,M["green"])
            text_obj("Final subtitle","A PRACTICAL GUIDE TO DIGITAL SECURITY",(x-1.1,-0.2,4.55),0.16,M["white"])
            text_obj("Final tagline","FOR BEGINNERS & PROFESSIONALS",(x-1.1,-0.2,4.05),0.15,M["muted"])
            text_obj("Final close","YOUR NEXT SAFER CLICK STARTS WITH WHAT YOU LEARN",(x,-0.2,1.1),0.14,M["cyan"])


def animate_sprites(sprites):
    expression_pose={"neutral":"idle","surprised":"alert","suspicious":"checking","thinking":"thinking","focused":"focused","relieved":"relieved","happy":"celebrate"}
    for item in sprites:
        ob=item["object"]; stage=item["stage"]; state=item["state"]
        start=stage*SEGMENT_FRAMES+state*150+1
        end=min(start+149,TOTAL_FRAMES)
        key_visibility(ob,start,end)
        x=item["home_x"]
        ob.location=(x-0.34,-2.2,2.60); ob.keyframe_insert(data_path="location",frame=start)
        ob.location=(x,-2.2,2.73); ob.keyframe_insert(data_path="location",frame=start+75)
        ob.location=(x+0.30,-2.2,2.62); ob.keyframe_insert(data_path="location",frame=end)
        ob.scale=(2.18,3.27,1); ob.keyframe_insert(data_path="scale",frame=start)
        ob.scale=(2.36,3.54,1); ob.keyframe_insert(data_path="scale",frame=start+75)
        ob.scale=(2.18,3.27,1); ob.keyframe_insert(data_path="scale",frame=end)


def animate_camera(scene):
    bpy.ops.object.camera_add(location=(0,-25,8.2))
    cam=bpy.context.object; cam.name="Phishing explainer cinematic camera"
    cam.data.type="ORTHO"; cam.data.ortho_scale=14.5; scene.camera=cam
    for i in range(STAGE_COUNT):
        cx=i*STAGE_SPACING
        shot_defs=[(0.0,0.0,-25.5,8.1,5.4),(5.0,-1.2,-21.5,7.2,5.0),(10.0,1.4,-19.5,6.4,4.7)]
        for sec,ox,yy,zz,tz in shot_defs:
            frame=i*SEGMENT_FRAMES+int(sec*FPS)+1
            cam.location=(cx+ox,yy,zz)
            target=Vector((cx,0.2,tz)); direction=target-cam.location
            cam.rotation_euler=direction.to_track_quat("-Z","Y").to_euler()
            cam.keyframe_insert(data_path="location",frame=frame)
            cam.keyframe_insert(data_path="rotation_euler",frame=frame)
    if cam.animation_data and cam.animation_data.action:
        try:
            for fc in cam.animation_data.action.fcurves:
                for kp in fc.keyframe_points: kp.interpolation="BEZIER"
        except Exception: pass
    # Subtle camera drift continues between authored camera cuts.
    try:
        fc=cam.driver_add("rotation_euler",1)
        fc.driver.expression="0.006*sin(frame*0.018)"
    except Exception: pass
    return cam


def add_lighting(scene,M):
    world=bpy.data.worlds.new("Phishing cyber city world") if not bpy.data.worlds else bpy.data.worlds[0]
    scene.world=world; world.use_nodes=True
    world.node_tree.nodes["Background"].inputs["Color"].default_value=PAL["void"]
    world.node_tree.nodes["Background"].inputs["Strength"].default_value=0.28
    # Give every one of the eight sets its own local softbox and coloured rims.
    # This avoids lighting the opening/closing worlds with distant lights intended
    # for the centre stages of the virtual corridor.
    for i in range(STAGE_COUNT):
        x=i*STAGE_SPACING
        lights=[
          ("Cool overhead softbox",(x,-9,19),2300,13,(0.34,0.67,1.0)),
          ("Cyan rim light",(x-7,2,10),1500,8,(0.02,0.55,1.0)),
          ("Teal back light",(x+7,6,9),1200,7,(0.02,0.70,0.58)),
          ("Front fill",(x,-17,8),1000,9,(0.56,0.75,0.94))]
        for n,loc,power,size,col in lights:
            bpy.ops.object.light_add(type="AREA",location=loc); o=bpy.context.object
            o.name=f"Stage {i+1} {n}"; o.data.energy=power; o.data.shape="DISK"; o.data.size=size; o.data.color=col
            o.rotation_euler=(math.radians(18),0,math.radians(8))


def animate_world(scene):
    # Motive movement: light pulses, floating particles and subtly moving hologram elements.
    animated=0
    for idx,o in enumerate(list(bpy.data.objects)):
        if o.name.startswith(("Data node","Hologram ring","Phone lock","Safe destination","Like icon halo","Subscribe icon halo")):
            base=tuple(o.location)
            try:
                fc=o.driver_add("location",2)
                fc.driver.expression="%.6f+0.08*sin(frame*0.035+%.5f)"%(base[2],idx*0.37)
                animated+=1
            except Exception: pass
        if o.type=="LIGHT":
            try:
                fc=o.data.driver_add("energy")
                fc.driver.expression="%.3f*(1+0.10*sin(frame*0.025+%.4f))"%(o.data.energy,idx*0.51)
                animated+=1
            except Exception: pass
    # A bright data packet travels through the corridor behind the characters.
    for i in range(STAGE_COUNT):
        x=i*STAGE_SPACING
        for j in range(4):
            ob=sphere("Moving data packet",(x-4+j*2.6,3.0,5.1+j*0.45),(0.09,0.09,0.09),MATERIALS["amber"],16,8)
            a=i*SEGMENT_FRAMES+1; b=min(a+SEGMENT_FRAMES-1,TOTAL_FRAMES)
            ob.location=(x-4+j*2.6,3.0,5.1); ob.keyframe_insert(data_path="location",frame=a)
            ob.location=(x-4+j*2.6,3.0,6.0); ob.keyframe_insert(data_path="location",frame=a+SEGMENT_FRAMES//2)
            ob.location=(x-4+j*2.6,3.0,5.1); ob.keyframe_insert(data_path="location",frame=b)
            animated+=1
    return animated


def configure_render(scene,outdir):
    scene.frame_start=1; scene.frame_end=TOTAL_FRAMES
    scene.render.engine="BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys() else "BLENDER_EEVEE"
    scene.render.resolution_x=WIDTH; scene.render.resolution_y=HEIGHT; scene.render.resolution_percentage=100
    scene.render.fps=FPS; scene.render.image_settings.file_format="PNG"
    scene.render.image_settings.color_mode="RGBA"; scene.render.image_settings.color_depth="8"
    scene.render.film_transparent=False; scene.render.use_file_extension=True
    scene.view_settings.view_transform="Standard"
    safe_set(scene.view_settings,"look","Medium High Contrast")
    safe_set(scene.view_settings,"exposure",0.0); safe_set(scene.view_settings,"gamma",1.0)
    if hasattr(scene,"eevee"):
        safe_set(scene.eevee,"taa_render_samples",64)
        safe_set(scene.eevee,"use_gtao",True)
        safe_set(scene.eevee,"gtao_distance",3.0)
        safe_set(scene.eevee,"gtao_factor",1.2)
        safe_set(scene.eevee,"use_soft_shadows",True)
    safe_set(scene.render,"use_motion_blur",True)
    safe_set(scene.render,"motion_blur_shutter",0.28)
    # Subtle glow pass for emissive neon elements.
    scene.use_nodes=True
    nt=scene.node_tree; nt.nodes.clear()
    rl=nt.nodes.new("CompositorNodeRLayers")
    glare=nt.nodes.new("CompositorNodeGlare"); glare.glare_type="FOG_GLOW"
    safe_set(glare,"threshold",1.5); safe_set(glare,"quality","MEDIUM")
    comp=nt.nodes.new("CompositorNodeComposite")
    nt.links.new(rl.outputs["Image"],glare.inputs["Image"])
    nt.links.new(glare.outputs["Image"],comp.inputs["Image"])
    os.makedirs(outdir,exist_ok=True)


def build_scene(root_dir,cover_path,outdir):
    bpy.ops.object.select_all(action="SELECT"); bpy.ops.object.delete(use_global=False)
    M={k:material(k,v,0.55 if k in ("steel","panel","panel2") else 0.12,0.32,1.5 if k in ("cyan","amber","green","red","blue","teal") else 0.0) for k,v in PAL.items()}
    global MATERIALS; MATERIALS=M
    # Stage 1: the original, expressive 2D characters are constructed as textured planes.
    sprites=stage_sprites(root_dir)
    # Stage 2: build every part of the 3D cyber-city environment and story props.
    world=bpy.data.worlds.new("Phishing city world") if not bpy.data.worlds else bpy.data.worlds[0]
    environment_base(M,world)
    stage_specific(M,cover_path)
    add_lighting(bpy.context.scene,M)
    # Stage 3: animate the 2D character planes inside the completed 3D world.
    animate_sprites(sprites)
    animate_camera(bpy.context.scene)
    moving=animate_world(bpy.context.scene)
    configure_render(bpy.context.scene,outdir)
    bpy.context.scene.frame_set(1); bpy.context.view_layer.update()
    return bpy.context.scene, sprites, moving


def audit(scene,sprites,moving,outdir):
    os.makedirs(outdir,exist_ok=True)
    cam=scene.camera; first=None; last=None
    for f in range(1,TOTAL_FRAMES+1):
        scene.frame_set(f); bpy.context.view_layer.update()
        loc=tuple(cam.matrix_world.translation)
        if not all(math.isfinite(v) for v in loc): raise RuntimeError(f"Invalid camera transform at frame {f}")
        if f==1: first=loc
        if f==TOTAL_FRAMES: last=loc
    scene.frame_set(1); bpy.context.view_layer.update()
    visible_state_count=sum(1 for s in sprites if s["object"].animation_data is not None)
    if visible_state_count < 32: raise RuntimeError("Not enough animated character states")
    if moving < 30: raise RuntimeError("Not enough continuously animated 3D elements")
    project=os.path.join(outdir,OUT_NAME+".blend")
    bpy.ops.wm.save_as_mainfile(filepath=project)
    report={"status":"PASS","duration_seconds":DURATION,"frame_count":TOTAL_FRAMES,
      "fps":FPS,"resolution":[WIDTH,HEIGHT],"renderer":scene.render.engine,
      "style":"Dark cinematic 3D cyber-city with 2D expressive character sprites",
      "characters":[{"name":"Maya","states":["surprised","suspicious","focused","thinking","relieved","happy"]},
                    {"name":"Juno","states":["neutral","suspicious","thinking","focused","relieved","happy"]}],
      "character_sprite_planes":len(sprites),"animated_environment_elements":moving,
      "camera_frames_checked":TOTAL_FRAMES,"camera_start":first,"camera_end":last,
      "shots":[{"title":a,"descriptor":b} for a,b in SHOTS],
      "midpoint_cta":"Like and subscribe", "ending_cta":"Buy CyberSpace Unlocked",
      "editable_project":os.path.basename(project)}
    with open(os.path.join(outdir,"audit.json"),"w",encoding="utf-8") as f: json.dump(report,f,indent=2)
    print("PHISHING_AUDIT_PASS",json.dumps({"frames":TOTAL_FRAMES,"character_sprites":len(sprites),"moving_elements":moving}),flush=True)


def render_segment(scene,seg,outdir):
    if seg<0 or seg>=STAGE_COUNT: raise ValueError("segment-index must be 0..7")
    os.makedirs(outdir,exist_ok=True)
    start=seg*SEGMENT_FRAMES+1; end=start+SEGMENT_FRAMES-1
    frame_dir=os.path.join(outdir,f"segment_{seg:02d}_frames"); os.makedirs(frame_dir,exist_ok=True)
    prefix=os.path.join(frame_dir,"frame_")
    scene.render.filepath=prefix; scene.render.image_settings.file_format="PNG"
    scene.render.image_settings.color_mode="RGBA"; scene.render.image_settings.color_depth="8"
    scene.render.resolution_x=WIDTH; scene.render.resolution_y=HEIGHT; scene.render.resolution_percentage=100
    scene.render.fps=FPS; scene.frame_start=start; scene.frame_end=end; scene.frame_set(start)
    print("PHISHING_RENDER_START",seg,start,end,WIDTH,HEIGHT,flush=True)
    bpy.ops.render.render(animation=True)
    path=os.path.join(outdir,f"segment_{seg:02d}.mp4")
    cmd=["ffmpeg","-y","-framerate",str(FPS),"-start_number",str(start),"-i",prefix+"%04d.png",
         "-frames:v",str(SEGMENT_FRAMES),"-c:v","libx264","-preset","medium","-crf","18",
         "-pix_fmt","yuv420p","-movflags","+faststart",path]
    subprocess.run(cmd,check=True)
    if not os.path.exists(path) or os.path.getsize(path)<100000: raise RuntimeError("Missing or undersized segment: "+path)
    print("PHISHING_SEGMENT_VERIFIED",path,os.path.getsize(path),flush=True)


def main():
    a=parse_args()
    root=os.path.dirname(os.path.abspath(__file__))
    cover=os.path.join(root,"assets","cyberspace_unlocked_cover.jpg")
    scene,sprites,moving=build_scene(root,cover,a.output_dir)
    if a.mode=="audit": audit(scene,sprites,moving,a.output_dir)
    else: render_segment(scene,a.segment_index,a.output_dir)

if __name__=="__main__": main()
