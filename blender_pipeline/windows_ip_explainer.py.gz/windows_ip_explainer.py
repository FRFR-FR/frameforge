"""FrameForge: 90-second Windows IP privacy explainer.

Native low-poly Blender scene; designed to match the bright, clean 3D
educational look of the supplied reference. Renders in six 15-second parts.
"""
import bpy, math, os, sys, json, argparse, shutil
from mathutils import Vector
FPS = 30
DURATION = 90
WIDTH, HEIGHT = (720, 1280)
TOTAL_FRAMES = FPS * DURATION
SEGMENT_SECONDS = 15
SEGMENT_FRAMES = FPS * SEGMENT_SECONDS
SHOT_SECONDS = 9
SHOT_FRAMES = FPS * SHOT_SECONDS
SHOT_COUNT = 10
OUT_NAME = 'FrameForge_Windows_IP_Privacy_90s'
C = {'sky': (0.56, 0.78, 0.88), 'grass': (0.4, 0.68, 0.34), 'grass2': (0.57, 0.77, 0.42), 'cream': (0.96, 0.92, 0.8), 'white': (0.99, 0.98, 0.92), 'blue': (0.055, 0.2, 0.47), 'blue2': (0.08, 0.39, 0.73), 'cyan': (0.12, 0.7, 0.76), 'teal': (0.1, 0.58, 0.5), 'green': (0.23, 0.58, 0.3), 'lime': (0.69, 0.83, 0.38), 'red': (0.84, 0.27, 0.22), 'orange': (0.95, 0.57, 0.24), 'ink': (0.065, 0.13, 0.2), 'muted': (0.35, 0.43, 0.46), 'lavender': (0.48, 0.49, 0.76), 'glass': (0.7, 0.87, 0.9), 'shadow': (0.16, 0.27, 0.25)}
SHOTS = [('YOUR IP IS YOUR INTERNET ADDRESS', 'Think of it as the return address for your connection'), ('IT CAN REVEAL YOUR APPROXIMATE REGION', 'Websites may use it to estimate where you connect from'), ('WINDOWS HAS VPN SETTINGS — NOT A VPN SERVICE', 'A VPN connection still needs a provider or server'), ('EDGE HAS A BUILT-IN OPTION', 'Microsoft Edge Secure Network uses VPN technology'), ('OPEN SECURE NETWORK', 'Three dots  →  More tools  →  Secure Network'), ('SIGN IN AND TURN IT ON', 'Use a personal Microsoft account, then select Get VPN for free'), ('CHOOSE YOUR COVERAGE', 'Optimized  •  Select Sites  •  All Sites'), ('LOOK FOR THE SHIELD', 'The icon appears when Secure Network is active'), ('CHECK THE RESULT', 'Compare your public IP on a supported website'), ('KNOW THE LIMITS', '5 GB each month  •  Edge browsing only  •  Not total anonymity')]

def args_parse():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument('--mode', choices=('audit', 'render'), default='audit')
    p.add_argument('--segment-index', type=int, default=0)
    p.add_argument('--output-dir', default='output/windows_ip_explainer')
    return p.parse_args(argv)

def mat(name, color, metallic=0.0, roughness=0.66):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get('Principled BSDF')
    if bs:
        bs.inputs['Base Color'].default_value = (*color, 1)
        bs.inputs['Metallic'].default_value = metallic
        bs.inputs['Roughness'].default_value = roughness
    return m

def emission_mat(name, color, strength=1.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Color'].default_value = (*color, 1)
    em.inputs['Strength'].default_value = strength
    nt.links.new(em.outputs[0], out.inputs['Surface'])
    return (m, em)

def cube(name, loc, dims, material, bevel=0.0, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.dimensions = dims
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.rotation_euler = rot
    if material:
        o.data.materials.append(material)
    if bevel:
        b = o.modifiers.new('Soft manufactured edges', 'BEVEL')
        b.width = bevel
        b.segments = 3
        o.modifiers.new('Weighted corner normals', 'WEIGHTED_NORMAL')
    return o

def ico(name, loc, scale, material, subdivisions=2):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=subdivisions, radius=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.scale = scale
    if material:
        o.data.materials.append(material)
    return o

def cylinder(name, loc, radius, depth, material, rot=(0, 0, 0), vertices=12):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rot)
    o = bpy.context.object
    o.name = name
    if material:
        o.data.materials.append(material)
    bevel = o.modifiers.new('Edge glint', 'BEVEL')
    bevel.width = min(radius * 0.16, 0.06)
    bevel.segments = 2
    o.modifiers.new('Weighted normals', 'WEIGHTED_NORMAL')
    return o

def torus(name, loc, major, minor, material, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=48, minor_segments=8, location=loc, rotation=rot)
    o = bpy.context.object
    o.name = name
    if material:
        o.data.materials.append(material)
    return o

def line(name, pts, thickness, material):
    d = bpy.data.curves.new(name, 'CURVE')
    d.dimensions = '3D'
    d.resolution_u = 2
    d.bevel_depth = thickness
    d.bevel_resolution = 3
    s = d.splines.new('POLY')
    s.points.add(len(pts) - 1)
    for p, co in zip(s.points, pts):
        p.co = (co[0], co[1], co[2], 1)
    o = bpy.data.objects.new(name, d)
    bpy.context.collection.objects.link(o)
    if material:
        d.materials.append(material)
    return o

def text3d(name, body, loc, size, material, rot=(math.pi / 2, 0, 0), align='CENTER'):
    d = bpy.data.curves.new(name, 'FONT')
    d.body = body
    d.size = size
    d.align_x = align
    d.align_y = 'CENTER'
    d.extrude = 0.003
    d.bevel_depth = 0.001
    o = bpy.data.objects.new(name, d)
    bpy.context.collection.objects.link(o)
    o.location = loc
    o.rotation_euler = rot
    if material:
        d.materials.append(material)
    return o

def front_text(name, body, x, y, z, size, material, align='CENTER'):
    return text3d(name, body, (x, y, z), size, material, (math.pi / 2, 0, 0), align)

def stage(index, mats):
    x = index * 28.0
    cube(f'Stage {index + 1} meadow', (x, 0, -0.42), (15, 24, 0.8), mats['grass'], 0.18)
    cube(f'Stage {index + 1} cream inset', (x, 0, 0.005), (10.5, 12.0, 0.06), mats['cream'], 0.12)
    for j, (dx, yy, sx, sy, sz) in enumerate([(-6, 8, 4.3, 2.0, 2.0), (-2, 10, 4.8, 2.4, 2.2), (4, 9, 4.2, 2.2, 1.9), (7, 11, 3.5, 1.8, 1.7)]):
        ico(f'Stage {index + 1} distant green hill {j}', (x + dx, yy, 0.1), (sx, sy, sz), mats['grass2'], 2)
    for j in range(5):
        dx = -6.5 + j * 3.2
        ico(f'Stage {index + 1} shrub {j}', (x + dx, 4.8, 0.48), (0.65, 0.6, 0.58), mats['green'], 1)
    return x

def laptop(x, y, z, mats, label='BROWSER'):
    cube(label + ' laptop base', (x, y - 0.45, z + 0.24), (4.5, 2.15, 0.22), mats['silver'], 0.11)
    cube(label + ' laptop keyboard deck', (x, y - 0.45, z + 0.37), (3.65, 1.55, 0.035), mats['muted'], 0.04)
    for r in range(3):
        for c in range(11):
            xx = x - 1.52 + c * 0.305
            zz = z + 0.402
            yy = y - 1.0 + r * 0.35
            cube(label + f' key {r}-{c}', (xx, yy, zz), (0.2, 0.19, 0.025), mats['cream'], 0.018)
    cube(label + ' screen bezel', (x, y + 0.55, z + 1.78), (4.2, 0.2, 2.75), mats['ink'], 0.16)
    cube(label + ' screen glass', (x, y + 0.435, z + 1.79), (3.93, 0.035, 2.47), mats['blue'], 0.07)
    cube(label + ' screen browser bar', (x, y + 0.407, z + 2.8), (3.82, 0.03, 0.3), mats['white'], 0.045)
    for k, col in enumerate([mats['red'], mats['orange'], mats['green']]):
        ico(label + f' browser dot{k}', (x - 1.72 + k * 0.14, y + 0.37, z + 2.81), (0.045, 0.035, 0.045), col, 1)
    front_text(label + ' browser title', 'SECURE BROWSING', x, y + 0.36, z + 2.81, 0.105, mats['ink'], 'LEFT')
    cube(label + ' page card', (x, y + 0.37, z + 1.92), (3.25, 0.035, 1.35), mats['white'], 0.06)
    cube(label + ' page hero', (x - 0.75, y + 0.34, z + 2.06), (1.45, 0.025, 0.42), mats['cyan'], 0.05)
    for r in range(3):
        cube(label + f' page line{r}', (x + 0.68, y + 0.34, z + 2.26 - r * 0.27), (1.1 - r * 0.1, 0.025, 0.075), mats['glass'], 0.025)

def globe(x, y, z, mats, r=2.15):
    ico('Blue low-poly globe', (x, y, z), (r, r, r), mats['blue2'], 3)
    for i, (dx, dz, sx, sz) in enumerate([(-0.72, 0.75, 0.75, 0.52), (0.48, 0.6, 0.62, 0.84), (0.72, -0.42, 0.78, 0.42), (-0.44, -0.73, 0.46, 0.72)]):
        yy = y - math.sqrt(max(0.25, r * r - dx * dx - dz * dz)) * 0.91
        ico(f'Globe continent {i}', (x + dx, yy, z + dz), (sx, 0.075, sz), mats['lime'], 1)
    for a in [-0.65, 0, 0.65]:
        pts = []
        for k in range(41):
            t = -math.pi / 2 + k * math.pi / 40
            xx = x + r * math.sin(t) * math.cos(a)
            zz = z + r * math.cos(t)
            yy = y - r * math.sin(t) * math.sin(a) - 0.04
            pts.append((xx, yy, zz))
        line('Globe meridian', pts, 0.018, mats['glass'])
    pts = []
    for k in range(65):
        a = 2 * math.pi * k / 64
        pts.append((x + r * math.cos(a), y - r * 0.04, z + r * 0.22 * math.sin(a)))
    line('Globe equator', pts, 0.018, mats['glass'])
    nodes = [(-1.0, 0.6), (0.15, 1.12), (0.9, -0.35), (-0.65, -0.85)]
    for i, (dx, dz) in enumerate(nodes):
        yy = y - math.sqrt(max(0.2, r * r - dx * dx - dz * dz)) * 1.02
        ico('Globe network node', (x + dx, yy, z + dz), (0.12, 0.1, 0.12), mats['orange'], 2)
    torus('Globe orbit ring', (x, y, z), r + 0.35, 0.035, mats['cyan'], (math.radians(74), 0, math.radians(24)))

def browser_panel(x, y, z, mats, title='Microsoft Edge', w=5.7, h=4.15):
    cube('Browser outer frame', (x, y, z), (w, 0.28, h), mats['white'], 0.18)
    cube('Browser screen', (x, y - 0.17, z - 0.05), (w - 0.22, 0.05, h - 0.35), mats['cream'], 0.1)
    cube('Browser top chrome', (x, y - 0.21, z + h / 2 - 0.28), (w - 0.28, 0.04, 0.42), mats['glass'], 0.06)
    for i, col in enumerate([mats['red'], mats['orange'], mats['green']]):
        ico('Browser window control', (x - w / 2 + 0.3 + i * 0.16, y - 0.26, z + h / 2 - 0.28), (0.055, 0.035, 0.055), col, 1)
    front_text('Browser title', title, x, y - 0.26, z + h / 2 - 0.28, 0.16, mats['ink'], 'LEFT')
    torus('Blue-green browser emblem', (x - 1.55, y - 0.29, z + 0.35), 0.68, 0.16, mats['cyan'], (math.pi / 2, 0, 0))
    torus('Deep blue browser emblem', (x - 1.55, y - 0.31, z + 0.35), 0.45, 0.12, mats['blue2'], (math.pi / 2, 0, 0))
    front_text('Browser name', 'SECURE NETWORK', x + 0.65, y - 0.29, z + 0.55, 0.23, mats['blue'], 'CENTER')
    front_text('Browser description', 'Privacy protection for supported browsing', x + 0.65, y - 0.29, z + 0.12, 0.115, mats['muted'], 'CENTER')
    return (x, y, z)

def shield(x, y, z, scale, mats):
    pts = [(-0.82, 0.7), (0.82, 0.7), (0.74, -0.2), (0.38, -0.78), (0, -1.12), (-0.38, -0.78), (-0.74, -0.2)]
    verts = []
    for yy in [-0.12, 0.12]:
        for px, pz in pts:
            verts.append((x + px * scale, y + yy, z + pz * scale))
    n = len(pts)
    faces = []
    faces.append(tuple(range(n)))
    faces.append(tuple(range(n, 2 * n)))
    for i in range(n):
        faces.append((i, (i + 1) % n, (i + 1) % n + n, i + n))
    me = bpy.data.meshes.new('Shield solid mesh')
    me.from_pydata(verts, [], faces)
    me.materials.append(mats['blue2'])
    me.update()
    ob = bpy.data.objects.new('Protective shield', me)
    bpy.context.collection.objects.link(ob)
    bev = ob.modifiers.new('Shield bevel', 'BEVEL')
    bev.width = 0.1 * scale
    bev.segments = 3
    ob.modifiers.new('Weighted normals', 'WEIGHTED_NORMAL')
    line('Shield check', [(x - 0.42 * scale, y - 0.17, z - 0.03 * scale), (x - 0.12 * scale, y - 0.18, z - 0.36 * scale), (x + 0.48 * scale, y - 0.18, z + 0.34 * scale)], 0.095 * scale, mats['white'])
    return ob

def make_materials():
    return {k: mat(k, v, 0.02 if k in ('silver', 'blue', 'blue2') else 0.0, 0.55) for k, v in {**C, 'silver': (0.72, 0.79, 0.8), 'pale': (0.91, 0.95, 0.88), 'darkblue': (0.035, 0.1, 0.25)}.items()}

def make_stage_objects(m):
    xs = []
    for i in range(SHOT_COUNT):
        xs.append(stage(i, m))
    x = xs[0]
    laptop(x, 0, 0.1, m, 'INTRO LAPTOP')
    cube('Floating IP label', (x + 2.35, -0.6, 3.35), (2.4, 0.22, 0.92), m['white'], 0.13)
    front_text('IP label caption', 'PUBLIC IP', x + 2.35, -0.73, 3.57, 0.12, m['muted'])
    front_text('IP sample', '203.0.113.42', x + 2.35, -0.73, 3.26, 0.17, m['blue'])
    line('IP connection dotted', [(x + 1.7, -0.4, 2.6), (x + 2.0, -0.5, 2.9), (x + 2.35, -0.5, 3.2)], 0.028, m['orange'])
    x = xs[1]
    globe(x, 0, 2.4, m, 2.2)
    cylinder('Location pin stem', (x + 2.25, -1.2, 2.65), 0.13, 0.95, m['red'])
    ico('Location pin head', (x + 2.25, -1.22, 3.2), (0.34, 0.18, 0.34), m['red'], 2)
    for r in [0.65, 1.05, 1.45]:
        torus('Regional signal ripple', (x + 2.25, -1.15, 1.72), r, 0.025, m['orange'], (math.pi / 2, 0, 0))
    x = xs[2]
    cube('Windows desktop tower', (x - 2.2, 0.25, 1.9), (1.45, 1.0, 3.1), m['silver'], 0.14)
    cube('Windows glowing screen', (x - 2.2, -0.29, 2.4), (1.14, 0.04, 1.55), m['blue'], 0.06)
    for dx, dz, col in [(-0.25, 0.22, m['cyan']), (0.0, 0.22, m['white']), (-0.25, -0.03, m['white']), (0.0, -0.03, m['cyan'])]:
        cube('Windows pane', (x - 2.2 + dx, -0.33, 2.4 + dz), (0.19, 0.025, 0.19), col, 0.012)
    for i, (dx, dz) in enumerate([(1.0, 3.5), (2.3, 2.0), (1.0, 0.65)]):
        cube(f'Separate app {i}', (x + dx, 0.1, dz), (0.95, 0.45, 0.78), m['white'], 0.09)
        ico(f'App indicator {i}', (x + dx, -0.2, dz), (0.2, 0.1, 0.2), [m['orange'], m['cyan'], m['green']][i], 1)
        line(f'Unprotected app path {i}', [(x - 1.3, -0.4, 2.2), (x + dx, -0.35, dz)], 0.035, m['red'])
    cube('Manual VPN settings card', (x + 2.9, 0.2, 4.35), (2.8, 0.3, 1.15), m['cream'], 0.12)
    front_text('Manual VPN label', 'ADD A VPN', x + 2.9, 0.0, 4.5, 0.19, m['blue'])
    front_text('Manual VPN sublabel', 'Server details required', x + 2.9, 0.0, 4.19, 0.12, m['muted'])
    x = xs[3]
    browser_panel(x, 0.25, 2.55, m, 'Microsoft Edge', 5.8, 4.35)
    shield(x + 2.25, -0.55, 1.9, 0.78, m)
    x = xs[4]
    browser_panel(x, 0.45, 3.05, m, 'Microsoft Edge  •  Settings', 5.8, 4.1)
    cube('Three-dot menu button', (x + 2.53, -0.45, 4.52), (0.44, 0.1, 0.42), m['white'], 0.08)
    for i in range(3):
        ico('Menu dot', (x + 2.4 + i * 0.13, -0.53, 4.52), (0.035, 0.025, 0.035), m['ink'], 1)
    cube('Expanded tools menu', (x + 1.15, -0.75, 2.5), (2.3, 0.18, 2.9), m['white'], 0.1)
    for i, label in enumerate(['New tab', 'Downloads', 'Extensions', 'More tools', 'Secure Network']):
        zz = 3.45 - i * 0.45
        if label == 'Secure Network':
            cube('Secure Network selected row', (x + 1.15, -0.88, zz), (2.06, 0.05, 0.38), m['cyan'], 0.045)
        front_text('Menu item ' + label, label, x + 1.15, -0.93, zz, 0.15, m['ink'] if label != 'Secure Network' else m['white'])
    x = xs[5]
    cube('Sign-in outer card', (x, 0.0, 2.65), (5.4, 0.28, 4.5), m['white'], 0.18)
    for i, col in enumerate([m['blue2'], m['red'], m['green'], m['orange']]):
        dx = i % 2 * 0.24 - 0.12
        dz = i // 2 * 0.24 + 3.95
        cube('Microsoft-like four pane', (x - 1.75 + dx, -0.2, dz), (0.2, 0.06, 0.2), col, 0.015)
    front_text('Account sign in title', 'SIGN IN', x, -0.21, 3.45, 0.28, m['blue'])
    front_text('Account sign in subtitle', 'Personal Microsoft account', x, -0.21, 2.98, 0.17, m['muted'])
    cube('Get VPN button', (x, -0.22, 1.85), (3.0, 0.12, 0.62), m['blue2'], 0.1)
    front_text('Get VPN button text', 'GET VPN FOR FREE', x, -0.31, 1.85, 0.19, m['white'])
    x = xs[6]
    modes = [('OPTIMIZED', 'Recommended', m['green']), ('SELECT SITES', 'Choose sites', m['cyan']), ('ALL SITES', 'Broad coverage', m['blue2'])]
    for i, (title, desc, col) in enumerate(modes):
        xx = x + (i - 1) * 2.25
        zz = 2.55 + (0.22 if i == 0 else 0)
        cube('Protection mode card ' + title, (xx, -0.05, zz), (2.0, 0.34, 3.25), m['white'], 0.15)
        cylinder('Mode color medallion', (xx, -0.29, 3.55), 0.31, 0.12, col, (math.pi / 2, 0, 0), 24)
        front_text('Mode title ' + title, title, xx, -0.3, 2.75, 0.18, m['blue'])
        front_text('Mode description ' + title, desc, xx, -0.3, 2.3, 0.13, m['muted'])
        if i == 0:
            cube('Recommended tab', (xx, -0.3, 1.45), (1.35, 0.06, 0.34), m['green'], 0.05)
            front_text('Recommended tag', 'RECOMMENDED', xx, -0.35, 1.45, 0.105, m['white'])
    x = xs[7]
    laptop(x, 0, 0.12, m, 'ACTIVE EDGE')
    shield(x + 2.0, -0.4, 2.35, 1.35, m)
    cube('Active status badge', (x - 2.1, -0.75, 4.15), (1.7, 0.16, 0.58), m['green'], 0.09)
    front_text('Active status text', 'PROTECTION ON', x - 2.1, -0.85, 4.15, 0.14, m['white'])
    x = xs[8]
    for i, (title, ip, col) in enumerate([('BEFORE', '203.0.113.42', m['red']), ('AFTER', '198.51.100.21', m['green'])]):
        xx = x + (i - 0.5) * 3.1
        cube(title + ' IP comparison card', (xx, 0.05, 2.55), (2.72, 0.26, 2.6), m['white'], 0.14)
        cube(title + ' IP color stripe', (xx, -0.12, 3.55), (2.45, 0.055, 0.18), col, 0.04)
        front_text(title + ' label', title, xx, -0.17, 3.15, 0.2, col)
        front_text(title + ' address', ip, xx, -0.17, 2.55, 0.17, m['blue'])
    ico('IP compare arrow', (x, -0.48, 2.5), (0.45, 0.15, 0.45), m['orange'], 2)
    front_text('Example addresses note', 'ILLUSTRATIVE TEST-NET ADDRESSES', x, -0.52, 1.02, 0.11, m['muted'])
    x = xs[9]
    limits = [('5 GB', 'per month', m['blue2']), ('EDGE', 'browser traffic', m['cyan']), ('NOT ANON', 'one privacy layer', m['orange'])]
    for i, (title, desc, col) in enumerate(limits):
        xx = x + (i - 1) * 2.35
        cube('Limit card ' + title, (xx, 0.05, 2.55), (2.1, 0.28, 2.65), m['white'], 0.15)
        cylinder('Limit icon disk', (xx, -0.19, 3.35), 0.42, 0.1, col, (math.pi / 2, 0, 0), 24)
        front_text('Limit title ' + title, title, xx, -0.24, 2.6, 0.2, m['blue'])
        front_text('Limit description ' + title, desc, xx, -0.24, 2.12, 0.125, m['muted'])
    cube('Final takeaway panel', (x, 0.3, 0.72), (5.6, 0.3, 0.58), m['blue'], 0.12)
    front_text('Final takeaway', 'USE IT AS ONE PRIVACY LAYER', x, 0.12, 0.72, 0.2, m['white'])
    return xs

def animate_scene_props():
    """Animate a network orbit so the 3D diagrams feel alive between cuts."""
    ob = bpy.data.objects.get('Globe orbit ring')
    if ob:
        start = SHOT_FRAMES + 1
        end = 2 * SHOT_FRAMES
        base = ob.rotation_euler.copy()
        ob.keyframe_insert(data_path='rotation_euler', frame=start)
        ob.rotation_euler.z = base.z + math.radians(115)
        ob.keyframe_insert(data_path='rotation_euler', frame=end)

def camera_for_shot(i, x, mats):
    data = bpy.data.cameras.new(f'Shot {i + 1:02d} camera data')
    cam = bpy.data.objects.new(f'Shot {i + 1:02d} camera', data)
    bpy.context.collection.objects.link(cam)
    data.lens = [44, 48, 46, 43, 46, 48, 43, 45, 47, 44][i]
    data.dof.use_dof = False
    locs = [(x, -17.5, 8.0), (x + 0.8, -16.0, 7.6), (x - 0.2, -18.0, 8.5), (x, -17.0, 7.2), (x + 0.6, -16.2, 7.4), (x, -17.2, 7.7), (x, -17.5, 8.3), (x + 0.4, -16.2, 7.2), (x, -16.8, 7.0), (x, -17.4, 7.8)]
    targets = [(x, 0, 2.3), (x, 0, 2.5), (x, 0.0, 2.25), (x, 0.0, 2.5), (x, 0, 2.55), (x, 0, 2.65), (x, 0, 2.55), (x, 0, 2.35), (x, 0, 2.55), (x, 0, 2.55)]
    cam.location = locs[i]
    direction = Vector(targets[i]) - cam.location
    cam.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    start = i * SHOT_FRAMES + 1
    end = (i + 1) * SHOT_FRAMES
    cam.keyframe_insert(data_path='location', frame=start)
    cam.location = cam.location + (targets[i] - Vector(locs[i])).normalized() * 0.45
    cam.keyframe_insert(data_path='location', frame=end)
    marker = bpy.context.scene.timeline_markers.new(f'SHOT_{i + 1:02d}', frame=start)
    marker.camera = cam
    return cam

def overlay_for_camera(cam, i, mats):
    start = i * SHOT_FRAMES + 1
    end = (i + 1) * SHOT_FRAMES
    title, subtitle = SHOTS[i]
    for label, body, y, size, color in [('headline', title, 3.65, 0.255, (0.045, 0.15, 0.25)), ('subtitle', subtitle, 3.12, 0.135, (0.22, 0.34, 0.37)), ('footer', 'WINDOWS PRIVACY  /  EDGE SECURE NETWORK', -4.45, 0.092, (0.3, 0.4, 0.4))]:
        m, em = emission_mat(f'Shot {i + 1} {label} emission', color, 0.0)
        d = bpy.data.curves.new(f'Shot {i + 1} {label}', 'FONT')
        d.body = body
        d.size = size
        d.align_x = 'CENTER'
        d.align_y = 'CENTER'
        d.extrude = 0.001
        ob = bpy.data.objects.new(f'Shot {i + 1} {label}', d)
        bpy.context.collection.objects.link(ob)
        ob.parent = cam
        ob.location = (0, y, -11.0)
        ob.rotation_euler = (0, math.pi, 0)
        d.materials.append(m)
        for f, val in [(max(1, start - 7), 0.0), (start + 7, 1.6), (end - 8, 1.6), (end, 0.0)]:
            em.inputs['Strength'].default_value = val
            em.inputs['Strength'].keyframe_insert(data_path='default_value', frame=f)

def setup_world_and_lights(scene):
    world = bpy.data.worlds.new('Pastel daylight sky')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.56, 0.76, 0.86, 1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.78
    scene.world = world

    def area(name, loc, power, color, size, target):
        d = bpy.data.lights.new(name, 'AREA')
        d.energy = power
        d.color = color
        d.shape = 'DISK'
        d.size = size
        o = bpy.data.objects.new(name, d)
        bpy.context.collection.objects.link(o)
        o.location = loc
        o.rotation_euler = (Vector(target) - o.location).to_track_quat('-Z', 'Y').to_euler()
    for i in range(SHOT_COUNT):
        x = i * 28.0
        area(f'Soft sun {i}', (x - 4, -7, 13), 1550, (1.0, 0.86, 0.68), 8, (x, 0, 1.4))
        area(f'Sky fill {i}', (x + 5, 5, 10), 950, (0.6, 0.82, 1.0), 10, (x, 0, 2.0))

def build_scene(output_dir):
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    for bank in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for b in list(bank):
            if b.users == 0:
                bank.remove(b)
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 12
    scene.cycles.use_denoising = True
    scene.render.resolution_x = WIDTH
    scene.render.resolution_y = HEIGHT
    scene.render.resolution_percentage = 100
    scene.render.fps = FPS
    scene.render.fps_base = 1.0
    scene.frame_start = 1
    scene.frame_end = TOTAL_FRAMES
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = max(1, min(4, os.cpu_count() or 2))
    scene.render.image_settings.color_mode = 'RGB'
    scene.render.film_transparent = False
    try:
        scene.view_settings.view_transform = 'AgX'
        scene.view_settings.look = 'AgX - Medium High Contrast'
        scene.view_settings.exposure = 0.1
        scene.view_settings.gamma = 1.0
    except Exception:
        try:
            scene.view_settings.view_transform = 'Standard'
            scene.view_settings.look = 'Medium High Contrast'
        except Exception:
            pass
    scene.render.use_file_extension = True
    scene.render.image_settings.file_format = 'PNG'
    scene.render.filepath = os.path.join(output_dir, 'frames', 'frame_')
    m = make_materials()
    m['silver'] = mat('Aluminium silver', (0.72, 0.79, 0.8), 0.28, 0.35)
    m['white'] = mat('Porcelain cream', C['white'])
    m['darkblue'] = mat('Deep interface blue', (0.035, 0.1, 0.25), 0.05, 0.35)
    setup_world_and_lights(scene)
    xs = make_stage_objects(m)
    animate_scene_props()
    for i, x in enumerate(xs):
        cam = camera_for_shot(i, x, m)
        overlay_for_camera(cam, i, m)
    scene.camera = bpy.data.objects.get('Shot 01 camera')
    scene.render.use_compositing = False
    return scene

def audit(scene, output_dir):
    cams = [o for o in bpy.data.objects if o.type == 'CAMERA']
    markers = [m for m in scene.timeline_markers if m.camera]
    assert len(cams) == SHOT_COUNT, f'Expected {SHOT_COUNT} shot cameras, got {len(cams)}'
    assert len(markers) == SHOT_COUNT, f'Expected {SHOT_COUNT} camera cuts, got {len(markers)}'
    assert scene.render.resolution_x == WIDTH and scene.render.resolution_y == HEIGHT
    assert scene.render.fps == FPS and scene.frame_end == TOTAL_FRAMES
    assert scene.render.engine == 'CYCLES' and scene.cycles.device == 'CPU'
    assert len([o for o in bpy.data.objects if 'Protective shield' in o.name]) >= 1
    assert any(('Expanded tools menu' in o.name for o in bpy.data.objects))
    assert any(('BEFORE IP comparison card' in o.name for o in bpy.data.objects))
    os.makedirs(output_dir, exist_ok=True)
    audit_data = {'project': OUT_NAME, 'duration_seconds': DURATION, 'frame_count': TOTAL_FRAMES, 'fps': FPS, 'resolution': [WIDTH, HEIGHT], 'renderer': 'Blender Cycles CPU', 'samples': scene.cycles.samples, 'shot_count': SHOT_COUNT, 'camera_cuts': len(markers), 'shots': [{'start_seconds': i * SHOT_SECONDS, 'end_seconds': (i + 1) * SHOT_SECONDS, 'title': SHOTS[i][0]} for i in range(SHOT_COUNT)], 'visual_style': 'bright low-poly 3D educational animation with pastel sky, meadow greens, cream panels, cobalt/cyan interface elements, soft studio daylight', 'source_note': 'All visuals are native Blender geometry and text; no AI-generated images or stock-footage dependencies.', 'disclaimers': ['Edge Secure Network is a browser protection feature, not a system-wide Windows VPN.', 'The free allowance is 5 GB per month for personal Microsoft accounts.', 'Availability varies by region, browser version and managed-device status.', 'Example IP addresses shown are documentation-only TEST-NET addresses.']}
    with open(os.path.join(output_dir, 'audit.json'), 'w', encoding='utf-8') as f:
        json.dump(audit_data, f, indent=2)
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(output_dir, OUT_NAME + '.blend'))
    print('FRAMEFORGE_WINDOWS_IP_AUDIT_OK', json.dumps(audit_data))

def render_segment(scene, segment, output_dir):
    if segment < 0 or segment >= DURATION // SEGMENT_SECONDS:
        raise ValueError('segment-index must be 0..5')
    os.makedirs(output_dir, exist_ok=True)
    start = segment * SEGMENT_FRAMES + 1
    end = (segment + 1) * SEGMENT_FRAMES
    scene.frame_start = start
    scene.frame_end = end
    scene.render.image_settings.file_format = 'FFMPEG'
    scene.render.ffmpeg.format = 'MPEG4'
    scene.render.ffmpeg.codec = 'H264'
    scene.render.ffmpeg.constant_rate_factor = 'PERC_LOSSLESS'
    scene.render.ffmpeg.ffmpeg_preset = 'GOOD'
    scene.render.ffmpeg.gopsize = 30
    scene.render.filepath = os.path.join(output_dir, f'segment_{segment:02d}.mp4')
    scene.frame_set(start)
    bpy.ops.render.render(animation=True)
    target = os.path.join(output_dir, f'segment_{segment:02d}.mp4')
    if not os.path.exists(target) or os.path.getsize(target) < 100000:
        raise RuntimeError('Segment MP4 missing or unexpectedly small: ' + target)
    print(f'FRAMEFORGE_SEGMENT_OK index={segment} frames={start}-{end} file={target} bytes={os.path.getsize(target)}')

def main():
    a = args_parse()
    os.makedirs(a.output_dir, exist_ok=True)
    scene = build_scene(a.output_dir)
    audit(scene, a.output_dir)
    if a.mode == 'render':
        render_segment(scene, a.segment_index, a.output_dir)
if __name__ == '__main__':
    main()
