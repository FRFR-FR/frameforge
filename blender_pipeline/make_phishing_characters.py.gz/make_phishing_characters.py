#!/usr/bin/env python3
"""Create the original 2D cut-out character pack used in the FrameForge 3D film."""
from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path
import math

OUT = Path(__file__).resolve().parent / "assets" / "characters"
OUT.mkdir(parents=True, exist_ok=True)
W, H, S = 512, 768, 2

CHARACTERS = {
    "maya": {
        "skin": (210, 151, 115), "skin_shadow": (157, 98, 76),
        "hair": (33, 25, 27), "hair_hi": (76, 48, 43),
        "top": (20, 151, 158), "top_hi": (56, 201, 202),
        "pants": (29, 43, 70), "shoes": (24, 29, 42),
        "accent": (250, 196, 84), "eyes": (30, 34, 45),
        "accessory": "earring"
    },
    "juno": {
        "skin": (117, 75, 61), "skin_shadow": (78, 47, 43),
        "hair": (27, 25, 33), "hair_hi": (66, 48, 56),
        "top": (213, 103, 50), "top_hi": (245, 157, 83),
        "pants": (31, 41, 65), "shoes": (20, 24, 39),
        "accent": (57, 197, 202), "eyes": (24, 23, 30),
        "accessory": "braids"
    },
}

EXPRESSIONS = ["neutral", "surprised", "suspicious", "thinking", "focused", "relieved", "happy"]
POSES = {"neutral", "open", "point", "thinking", "confident", "thumbsup"}


def scale_box(box):
    return tuple(int(v*S) for v in box)


def draw_person(name, expression, pose):
    p = CHARACTERS[name]
    im = Image.new("RGBA", (W*S, H*S), (0,0,0,0))
    d = ImageDraw.Draw(im)
    def ell(box, fill, outline=(27,31,44), width=7):
        d.ellipse(scale_box(box), fill=fill, outline=outline, width=width*S if width else 0)
    def rr(box, radius, fill, outline=(27,31,44), width=7):
        d.rounded_rectangle(scale_box(box), radius=radius*S, fill=fill, outline=outline, width=width*S if width else 0)
    def line(points, fill, width=18):
        d.line([(int(x*S),int(y*S)) for x,y in points], fill=fill, width=width*S, joint="curve")
    ink=(27,31,44,255)
    # Ground shadow and legs
    ell((116,690,396,730),(0,0,0,48),outline=(0,0,0,0),width=0)
    leg_shift = -12 if pose in ("point","open") else (10 if pose=="confident" else 0)
    rr((188+leg_shift,520,244+leg_shift,684),24,p["pants"]+(255,),ink,7)
    rr((270-leg_shift,520,326-leg_shift,684),24,p["pants"]+(255,),ink,7)
    # Shoe highlights
    rr((157+leg_shift,666,256+leg_shift,713),18,p["shoes"]+(255,),ink,7)
    rr((270-leg_shift,666,369-leg_shift,713),18,p["shoes"]+(255,),ink,7)
    line([(181+leg_shift,687),(235+leg_shift,687)],(90,119,144,255),5)
    line([(294-leg_shift,687),(348-leg_shift,687)],(90,119,144,255),5)
    # Arms first, with differing silhouette poses
    shoulder_l=(182,380); shoulder_r=(332,380)
    if pose=="open":
        left=[shoulder_l,(128,340),(80,285)]; right=[shoulder_r,(388,340),(431,290)]
    elif pose=="point":
        left=[shoulder_l,(137,430),(120,498)]; right=[shoulder_r,(390,340),(459,302)]
    elif pose=="thinking":
        left=[shoulder_l,(143,435),(174,500)]; right=[shoulder_r,(381,350),(330,285)]
    elif pose=="confident":
        left=[shoulder_l,(130,410),(148,480)]; right=[shoulder_r,(385,410),(370,480)]
    elif pose=="thumbsup":
        left=[shoulder_l,(132,430),(115,500)]; right=[shoulder_r,(393,350),(409,260)]
    else:
        left=[shoulder_l,(142,435),(132,520)]; right=[shoulder_r,(374,435),(383,520)]
    line(left,ink,42); line(left,p["top"]+(255,),27)
    line(right,ink,42); line(right,p["top"]+(255,),27)
    # Hands
    ell((left[-1][0]-22,left[-1][1]-18,left[-1][0]+22,left[-1][1]+24),p["skin"]+(255,),ink,6)
    if pose=="thumbsup":
        ell((389,222,432,280),p["skin"]+(255,),ink,6)
        line([(409,255),(412,208)],p["skin"]+(255,),18)
        line([(409,255),(412,208)],ink,6)
    else:
        ell((right[-1][0]-23,right[-1][1]-22,right[-1][0]+23,right[-1][1]+22),p["skin"]+(255,),ink,6)
    # Torso, hoodie/jacket, inner panel
    rr((145,340,370,555),62,p["top"]+(255,),ink,8)
    rr((169,362,347,531),44,p["top_hi"]+(255,),outline=(255,255,255,45),width=2)
    # Distinct jacket/hood details
    line([(257,365),(257,520)],(19,81,94,255),6)
    line([(188,395),(214,424),(235,402)],p["accent"]+(255,),7)
    ell((242,515,272,545),p["accent"]+(255,),outline=ink,width=4)
    # Hoodie hood edge and shoulders
    d.arc(scale_box((173,306,345,436)),180,360,fill=ink,width=9*S)
    # Neck
    rr((222,299,293,380),20,p["skin"]+(255,),ink,5)
    # Head and ears
    ell((117,88,393,354),p["skin"]+(255,),ink,9)
    ell((104,207,141,267),p["skin"]+(255,),ink,5)
    ell((370,207,407,267),p["skin"]+(255,),ink,5)
    # Hair silhouettes vary
    if name=="maya":
        ell((110,55,401,236),p["hair"]+(255,),ink,7)
        # Hairline mask reveals forehead and temples
        ell((143,115,370,326),p["skin"]+(255,),outline=(0,0,0,0),width=0)
        for cx,cy,r in [(145,118,42),(187,82,37),(235,68,39),(286,75,42),(345,112,45),(118,168,35),(390,167,35)]:
            ell((cx-r,cy-r,cx+r,cy+r),p["hair"]+(255,),ink,5)
        # Curly rim highlights
        for cx,cy in [(167,83),(234,53),(300,62),(361,103)]:
            ell((cx-13,cy-11,cx+6,cy+7),p["hair_hi"]+(255,),outline=(0,0,0,0),width=0)
    else:
        ell((124,54,388,226),p["hair"]+(255,),ink,7)
        ell((149,115,362,324),p["skin"]+(255,),outline=(0,0,0,0),width=0)
        # Braided crown + two side braids
        for cx,cy,r in [(160,95,37),(205,62,35),(254,58,36),(309,68,35),(355,108,39)]:
            ell((cx-r,cy-r,cx+r,cy+r),p["hair"]+(255,),ink,5)
        for k in range(4):
            ell((119+k*8,174+k*25,148+k*8,211+k*25),p["hair"]+(255,),ink,4)
            ell((365-k*8,174+k*25,394-k*8,211+k*25),p["hair"]+(255,),ink,4)
    # Facial expression
    if expression=="surprised":
        brow_y=190; eye_y=220; mouth='O'
        d.arc(scale_box((163,158,220,197)),190,350,fill=ink,width=7*S)
        d.arc(scale_box((292,158,349,197)),190,350,fill=ink,width=7*S)
        ell((168,197,211,251),(255,255,255,255),ink,4); ell((300,197,343,251),(255,255,255,255),ink,4)
        ell((183,211,200,237),p["eyes"]+(255,),outline=(0,0,0,0),width=0); ell((313,211,330,237),p["eyes"]+(255,),outline=(0,0,0,0),width=0)
        ell((225,267,286,319),(61,34,39,255),ink,5)
    elif expression in ("suspicious","focused"):
        line([(163,200),(211,187)],ink,7); line([(301,187),(348,200)],ink,7)
        ell((172,210,210,249),(255,255,255,255),ink,4); ell((301,210,339,249),(255,255,255,255),ink,4)
        ell((190,225,203,243),p["eyes"]+(255,),outline=(0,0,0,0),width=0); ell((317,225,330,243),p["eyes"]+(255,),outline=(0,0,0,0),width=0)
        if expression=="focused":
            line([(224,287),(256,291),(288,287)],ink,6)
        else:
            d.arc(scale_box((225,262,292,317)),200,340,fill=ink,width=6*S)
    elif expression=="thinking":
        line([(164,194),(210,199)],ink,7); line([(302,199),(348,190)],ink,7)
        ell((172,211,211,251),(255,255,255,255),ink,4); ell((301,211,340,251),(255,255,255,255),ink,4)
        ell((191,229,203,245),p["eyes"]+(255,),outline=(0,0,0,0),width=0); ell((317,229,330,245),p["eyes"]+(255,),outline=(0,0,0,0),width=0)
        line([(232,292),(280,292)],ink,6)
    elif expression in ("relieved","happy"):
        line([(164,198),(210,188)],ink,6); line([(302,188),(348,198)],ink,6)
        d.arc(scale_box((165,205,218,255)),190,350,fill=ink,width=6*S)
        d.arc(scale_box((295,205,348,255)),190,350,fill=ink,width=6*S)
        if expression=="happy":
            d.arc(scale_box((209,257,307,331)),15,165,fill=ink,width=9*S)
            line([(225,302),(290,302)],(255,255,255,230),4)
        else:
            d.arc(scale_box((224,265,289,321)),185,350,fill=ink,width=6*S)
    else:
        line([(163,195),(212,195)],ink,7); line([(300,195),(349,195)],ink,7)
        ell((172,211,211,250),(255,255,255,255),ink,4); ell((301,211,340,250),(255,255,255,255),ink,4)
        ell((189,226,204,243),p["eyes"]+(255,),outline=(0,0,0,0),width=0); ell((317,226,332,243),p["eyes"]+(255,),outline=(0,0,0,0),width=0)
        d.arc(scale_box((221,264,292,316)),10,170,fill=ink,width=7*S)
    # Nose bridge and cheek accents
    line([(256,235),(250,264)],p["skin_shadow"]+(255,),4)
    ell((151,258,176,273),(238,132,125,85),outline=(0,0,0,0),width=0)
    ell((335,258,360,273),(238,132,125,85),outline=(0,0,0,0),width=0)
    if CHARACTERS[name]["accessory"]=="earring":
        ell((381,258,397,276),p["accent"]+(255,),ink,3)
    # Foreground shine on clothing and shoes
    line([(174,383),(197,373),(224,375)],(255,255,255,75),5)
    # Reduce to target resolution with antialiasing
    im=im.resize((W,H),Image.Resampling.LANCZOS)
    path=OUT/f"{name}_{expression}_{pose}.png"
    im.save(path,optimize=True)
    return path


if __name__ == "__main__":
    made=[]
    for name in CHARACTERS:
        for expression in EXPRESSIONS:
            pose = {
                "neutral":"neutral", "surprised":"open", "suspicious":"point",
                "thinking":"thinking", "focused":"confident", "relieved":"open", "happy":"thumbsup"
            }[expression]
            made.append(draw_person(name, expression, pose))
    print(f"CHARACTER_ASSETS_CREATED={len(made)}")
    for p in made: print(p.name)
